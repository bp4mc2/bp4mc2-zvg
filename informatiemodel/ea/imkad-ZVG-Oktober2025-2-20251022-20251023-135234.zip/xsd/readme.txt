Op dit moment is er nog geen apart schema voor MIM 1.1 Kadaster uitbreidingen. 
Alle constructies waarnaar vanuit de conceptuele schemas verwezen wordt vallen binnen de xs: namespace.
Wanneer aparte MIM 1.1 Kadaster uitbreidingsconstructies een eigen schema definitie hebben, worden deze op deze plek toegevoegd.